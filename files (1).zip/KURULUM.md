# Maç Analiz: telefon uygulaması kurulumu

Sonuç: Telefonunun ana ekranında "Maç Analiz" simgesi olur. Her sabah 09:00'da (Türkiye saati) bot
GitHub'un bulutunda kendiliğinden çalışır, bilgisayarın kapalı olabilir. Uygulama o günün Banko seçimlerini,
Toplam Gol, Maç Sonu, Skor ve Takip bölümlerini gösterir.

## Gerekenler
- GitHub hesabı (ücretsiz): github.com
- football-data.org token'ın (zaten var)
- İsteğe bağlı: Claude API anahtarı (haber taraması ve yorum için, kullanıma göre ücretli)
- İsteğe bağlı: Telegram bot token'ı ve chat numaran (bilgisayardaki `telegram.txt` dosyasının 1. ve 2. satırı)

## 1) Depo oluştur
1. github.com'da giriş yap, sağ üstte **+ > New repository**.
2. Adı `mac-analiz`, **Public** seç. Hiçbir kutuyu işaretleme. **Create repository**.

## 2) Dosyaları yükle
1. Bu zip'i bilgisayarda aç.
2. Depo sayfasında **uploading an existing file** bağlantısına tıkla.
3. `mac_analiz_bot_v2.py` dosyasını ve `docs` klasörünü sürükle bırak, **Commit changes**'e bas.
4. Başında nokta olan gizli dosyalar (`.github` klasörü ve `.gitignore`) sürüklemeyle yüklenmeyebilir.
   Bunları şöyle oluştur: **Add file > Create new file**.
   - Ad kutusuna `.github/workflows/gunluk.yml` yaz (eğik çizgiler klasörleri oluşturur), içine zip'teki
     `.github/workflows/gunluk.yml` dosyasının içeriğini yapıştır, **Commit changes**.
   - Aynı şekilde ad `.gitignore`, içeriği zip'teki `.gitignore`.

**ÖNEMLİ:** `token.txt`, `telegram.txt` ve `anthropic.txt` dosyalarını ASLA yükleme. Şifrelerin bunlarda.
Depo herkese açık olduğu için sırlar yalnızca 3. adımdaki gizli alanlara girilir.

## 3) Sırları ekle
Depoda **Settings > Secrets and variables > Actions > New repository secret**. Tek tek ekle:

| Ad | Değer | Zorunlu mu |
|---|---|---|
| `FOOTBALL_DATA_TOKEN` | football-data.org token'ın | Evet |
| `ANTHROPIC_API_KEY` | Claude API anahtarı | Hayır |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token'ı | Hayır |
| `TELEGRAM_CHAT_ID` | Telegram chat numaran | Hayır |

## 4) Yayın adresini aç
**Settings > Pages** > Source: **Deploy from a branch** > Branch: `main`, klasör: `/docs` > **Save**.
Birkaç dakika sonra adresin: `https://KULLANICIADIN.github.io/mac-analiz/`

## 5) İlk çalıştırma (bir kere)
1. Üstte **Actions** sekmesi. Bir uyarı çıkarsa "I understand my workflows, go ahead and enable them" de.
2. Soldan **Gunluk analiz > Run workflow**. `test` kutusuna `true` yaz, **Run workflow**.
   Bu 6-8 dakika sürer: geçen sezon verisini indirir, geçmiş maçlarda modeli ölçer ve ayarlar.
3. Bittikten sonra bir kez daha **Run workflow** (bu sefer `test` boş/false) ile bugünün analizini üret.
   Sonrasında her sabah kendisi çalışır.

## 6) Telefona kur
- **Android (Chrome):** adresi aç, ⋮ menü > **Uygulamayı yükle** (ya da Ana ekrana ekle).
- **iPhone (Safari):** adresi aç, Paylaş simgesi > **Ana Ekrana Ekle**.

## Bilmen gerekenler
- Depo herkese açık olduğundan günlük seçimler (data.json) ve takip dosyası da herkese açık olur. Şifrelerin gizli kalır.
  Depoyu gizli yapmak için GitHub'ın ücretli planı gerekebilir.
- GitHub zamanlayıcısı birkaç dakika gecikebilir. Depo uzun süre hareketsiz kalırsa zamanlanmış çalışmayı durdurabilir;
  durursa Actions sekmesinden yeniden etkinleştir.
- Bilgisayardaki bot aynen çalışmaya devam eder, ikisi ayrı kayıt tutar.
- Güncellemek için `mac_analiz_bot_v2.py` dosyasını depoda değiştir (kalem simgesi ya da yeniden yükleme).

## Hatırlatma
Bu bir istatistiksel analiz aracıdır, garanti vermez. Sakatlık ve kadroyu bilmez. Banko seçimlerin birlikte
tutma ihtimali düşüktür. Kaybetmeyi göze alamayacağın parayla oynama.
